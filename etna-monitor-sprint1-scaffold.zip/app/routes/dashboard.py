from flask import Blueprint, render_template

bp = Blueprint("dashboard", __name__)

@bp.route("/")
def dashboard_home():
    # TODO: inject real user state (Free/Premium) & Telegram link status
    return render_template("dashboard.html", user={"tier": "Free", "telegram_linked": False})
