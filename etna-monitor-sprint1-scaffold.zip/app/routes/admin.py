from flask import Blueprint, render_template

bp = Blueprint("admin", __name__)

@bp.route("/")
def admin_home():
    # TODO: protect with real admin auth
    users = [
        {"email": "demo@example.com", "premium": False, "chat_id": None},
    ]
    return render_template("admin.html", users=users)
