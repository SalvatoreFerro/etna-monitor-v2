from dataclasses import dataclass

@dataclass
class User:
    email: str
    password_hash: str
    premium: bool = False
    chat_id: str | None = None
